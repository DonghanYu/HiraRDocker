OhdsiSharing 0.2.2
==================

Bug fixes:

1. Fixed error in DESCRIPTION file that could lead to an error when building the package.


OhdsiSharing 0.2.1
==================

Changes:

1. sftpUploadFile now allows specifying the remote folder to upload to.


OhdsiSharing 0.2.0
==================

Changes:

1. Dropping S3 support.

2. Adding SFTP support.
