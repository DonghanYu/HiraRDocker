structure(list(url = "http://atlas-dev.ohdsi.org/WebAPI/cohortdefinition/1e+09/generate/SYNPUF5PCT", 
    status_code = 500L, headers = structure(list(vary = "Accept-Encoding", 
        `content-encoding` = "gzip", `content-type` = "application/json", 
        `content-length` = "219", date = "Sun, 18 Jul 2021 21:19:48 GMT", 
        connection = "close"), class = c("insensitive", "list"
    )), all_headers = list(list(status = 500L, version = "HTTP/1.1", 
        headers = structure(list(vary = "Accept-Encoding", `content-encoding` = "gzip", 
            `content-type` = "application/json", `content-length` = "219", 
            date = "Sun, 18 Jul 2021 21:19:48 GMT", connection = "close"), class = c("insensitive", 
        "list")))), cookies = structure(list(domain = logical(0), 
        flag = logical(0), path = logical(0), secure = logical(0), 
        expiration = structure(numeric(0), class = c("POSIXct", 
        "POSIXt")), name = logical(0), value = logical(0)), row.names = integer(0), class = "data.frame"), 
    content = charToRaw("{\"payload\":{\"cause\":null,\"stackTrace\":[],\"message\":\"An exception occurred: org.glassfish.jersey.server.ParamException$PathParamException\",\"localizedMessage\":\"An exception occurred: org.glassfish.jersey.server.ParamException$PathParamException\",\"suppressed\":[]},\"headers\":{\"id\":\"a40f27e6-433b-22f8-005d-3bae76d4840c\",\"timestamp\":1626643188944}}"), 
    date = structure(1626643188, class = c("POSIXct", "POSIXt"
    ), tzone = "GMT"), times = c(redirect = 0, namelookup = 6.1e-05, 
    connect = 6.4e-05, pretransfer = 0.000188, starttransfer = 0.055332, 
    total = 0.055378)), class = "response")
