structure(list(url = "http://atlas-dev.ohdsi.org/WebAPI/vocabulary/SYNPUF5PCT/resolveConceptSetExpression", 
    status_code = 500L, headers = structure(list(vary = "Accept-Encoding", 
        `content-encoding` = "gzip", `content-type` = "application/json", 
        `content-length` = "199", date = "Fri, 16 Jul 2021 21:11:01 GMT", 
        connection = "close"), class = c("insensitive", "list"
    )), all_headers = list(list(status = 500L, version = "HTTP/1.1", 
        headers = structure(list(vary = "Accept-Encoding", `content-encoding` = "gzip", 
            `content-type` = "application/json", `content-length` = "199", 
            date = "Fri, 16 Jul 2021 21:11:01 GMT", connection = "close"), class = c("insensitive", 
        "list")))), cookies = structure(list(domain = logical(0), 
        flag = logical(0), path = logical(0), secure = logical(0), 
        expiration = structure(numeric(0), class = c("POSIXct", 
        "POSIXt")), name = logical(0), value = logical(0)), row.names = integer(0), class = "data.frame"), 
    content = charToRaw("{\"payload\":{\"cause\":null,\"stackTrace\":[],\"message\":\"An exception occurred: java.lang.NullPointerException\",\"localizedMessage\":\"An exception occurred: java.lang.NullPointerException\",\"suppressed\":[]},\"headers\":{\"id\":\"09e05832-9a57-e135-1553-36eec5185b73\",\"timestamp\":1626469861895}}"), 
    date = structure(1626469861, class = c("POSIXct", "POSIXt"
    ), tzone = "GMT"), times = c(redirect = 0, namelookup = 3.3e-05, 
    connect = 3.4e-05, pretransfer = 7.8e-05, starttransfer = 0.034803, 
    total = 0.034856)), class = "response")
